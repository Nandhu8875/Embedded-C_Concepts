#define GPIO_OUT_REG        (*(volatile unsigned int *)0x3FF44004)
#define GPIO_ENABLE_REG     (*(volatile unsigned int *)0x3FF44020)
#define GPIO2_IOMUX_REG     (*(volatile unsigned int *)0x3FF49040)

#define TIMG0_T0CONFIG_REG  (*(volatile unsigned int *)0x3FF5F000)

#define TIMG0_T0LO_REG      (*(volatile unsigned int *)0x3FF5F004)
#define TIMG0_T0HI_REG      (*(volatile unsigned int *)0x3FF5F008)
#define TIMG0_T0UPDATE_REG  (*(volatile unsigned int *)0x3FF5F00C)

#define TIMG0_T0ALARMLO_REG (*(volatile unsigned int *)0x3FF5F010)
#define TIMG0_T0ALARMHI_REG (*(volatile unsigned int *)0x3FF5F014)

#define TIMG0_T0LOADLO_REG  (*(volatile unsigned int *)0x3FF5F018)
#define TIMG0_T0LOADHI_REG  (*(volatile unsigned int *)0x3FF5F01C)
#define TIMG0_T0LOAD_REG    (*(volatile unsigned int *)0x3FF5F020)

#define TIMG0_INT_ENA_REG   (*(volatile unsigned int *)0x3FF5F098)
#define TIMG0_INT_RAW_REG   (*(volatile unsigned int *)0x3FF5F09C)
#define TIMG0_INT_ST_REG    (*(volatile unsigned int *)0x3FF5F0A0)
#define TIMG0_INT_CLR_REG   (*(volatile unsigned int *)0x3FF5F0A4)


void app_main(void)
{
    /* ---------------- GPIO2 : LED OUTPUT ---------------- */

    // GPIO2 -> Function 0 = GPIO2
    GPIO2_IOMUX_REG &= ~(7 << 12);

    // GPIO2 output enable
    GPIO_ENABLE_REG |= (1 << 2);

    // LED initially OFF
    GPIO_OUT_REG &= ~(1 << 2);


    /* ---------------- TIMER CONFIGURATION ---------------- */

    // Timer OFF
    TIMG0_T0CONFIG_REG &= ~(1 << 31);

    // Divider [28:13] clear
    TIMG0_T0CONFIG_REG &= ~(0xFFFF << 13);

    // Divider = 80
    TIMG0_T0CONFIG_REG |= (80 << 13);

    // Count UP
    TIMG0_T0CONFIG_REG |= (1 << 30);

    // Auto reload ON
    TIMG0_T0CONFIG_REG |= (1 << 29);


    /* ---------------- TIMER START VALUE ---------------- */

    // Start counter from 0
    TIMG0_T0LOADLO_REG = 0;
    TIMG0_T0LOADHI_REG = 0;

    // Any write triggers reload
    TIMG0_T0LOAD_REG = 0;


    /* ---------------- ALARM ---------------- */

    // Alarm = 1,000,000 ticks
    TIMG0_T0ALARMLO_REG = 1000000;
    TIMG0_T0ALARMHI_REG = 0;

    // Alarm enable
    TIMG0_T0CONFIG_REG |= (1 << 10);


    /* ---------------- TIMER START ---------------- */

    TIMG0_T0CONFIG_REG |= (1 << 31);


    /* ---------------- MAIN LOOP ---------------- */

    while (1)
    {
        // Check Timer 0 raw interrupt status
        if (TIMG0_INT_RAW_REG & (1 << 0))
        {
            // Toggle LED
            GPIO_OUT_REG ^= (1 << 2);

            // Clear Timer 0 interrupt
            TIMG0_INT_CLR_REG |= (1 << 0);

            // Alarm enable was automatically cleared after alarm
            // Enable it again for the next alarm
            TIMG0_T0CONFIG_REG |= (1 << 10);
        }
    }
}