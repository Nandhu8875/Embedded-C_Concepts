#include <stdio.h>


#define GPIO_OUT_REG  (*(volatile unsigned int *)0x3FF44004)

#define GPIO_ENB_REG  (*(volatile unsigned int *)0x3FF44020)

#define GPIO2_IOMUX_REG  (*(volatile unsigned int *)0x3FF49040)
#define GPIO4_IOMUX_REG  (*(volatile unsigned int *)0x3FF49048)

#define GPIO_INPUT_REG  (*(volatile unsigned int *)0x3FF4403C)



void app_main(void)
{

GPIO_ENB_REG |=(1<<2);
GPIO2_IOMUX_REG &=~(7<<12);

GPIO4_IOMUX_REG &=~(7<<12);

GPIO4_IOMUX_REG |=  (1 << 7);  // WPD ON
GPIO4_IOMUX_REG &= ~(1 << 8);  // WPU OFF

while(1)
{
  if(GPIO_INPUT_REG &(1<<4))
  {
    GPIO_OUT_REG |=(1<<2);
  }
  else{
    GPIO_OUT_REG &=~(1<<2);
  }
}

}
